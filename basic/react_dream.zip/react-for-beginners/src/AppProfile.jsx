import './App.css';

function AppPfofile() {
  
  return (
    <>
    <Profile/>
    </>
  );
}

export default AppPfofile;
